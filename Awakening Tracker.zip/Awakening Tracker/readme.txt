Awakening Tracker App v0.0.2 (6/16/2023) created by PissMidas

Double click the 'Awakening Tracker' app to use it.
The app closes automatically when Omega Strikers is not running.
No installation is required.

if you need support please visit this link (it's the main omega strikers discord) and post in this thread. https://discord.com/channels/780470426010255380/1119008450689634346/1119008450689634346
