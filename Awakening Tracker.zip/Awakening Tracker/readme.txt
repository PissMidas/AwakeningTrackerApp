Awakening Tracker App v0.0.1 (6/15/2023) created by PissMidas

Extract the zipped folder, then double click 'Awakening Tracker.exe' to use it.
The app closes automatically when Omega Strikers is not running.
No installation is required.

if you need support please visit this link (it's the main omega strikers discord) and post in this thread. https://discord.com/channels/780470426010255380/1119008450689634346/1119008450689634346
